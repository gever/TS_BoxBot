# Firmware Flashing Instructions for ESP32

This document provides detailed instructions on how to flash the firmware onto the ESP32 device using the provided `flash_firmware.sh` script. Follow these steps carefully to ensure successful firmware installation.

## Prerequisites

Before you begin, ensure that you have the following prerequisites installed on your system:

- **Python 3.x**: Make sure Python 3 and pip (Python's package manager) are installed. Python is required to run the `esptool.py` script, which is used for flashing the firmware.

1. Extract the Package: Unzip release_package.zip into a directory on your computer.

2. Navigate to the Script Directory: Open a terminal and change to the directory containing the extracted files.

3. Connect the ESP32: Ensure that the ESP32 device is connected to your computer via a USB-to-serial adapter. Check the serial port name assigned to your device (e.g., /dev/ttyUSB0 on Linux or COM3 on Windows).

./flash_firmware.sh /dev/ttyUSB0

4. Once the script completes, the ESP32 should be running the new firmware.

5. Run boxbot, with battery pack connected
    I.  choose wifi, e.g boxbot**
    II.  connect to http://boxbot.home (make sure you specify http://)
    III.  test out the commands in the browser