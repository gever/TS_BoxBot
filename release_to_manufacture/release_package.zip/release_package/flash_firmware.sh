#!/bin/bash
echo "Installing required Python packages..."
pip install -r requirements.txt

echo "Erasing Flash..."
python esptool.py --chip esp32 --port "$1" --baud 115200 erase_flash

echo "Flashing Firmware..."
python esptool.py --chip esp32 --port "$1" --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size detect 0x1000 bootloader.bin 0x10000 firmware.bin 0x8000 partitions.bin

echo "Firmware has been flashed successfully!"
